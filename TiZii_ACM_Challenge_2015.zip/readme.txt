This Client Is Coded By Intellij Idea IDE.

Jar File Provided. (TiZii_Client.jar)

Contact Info: imn.irdst@gmail.com	09395261668